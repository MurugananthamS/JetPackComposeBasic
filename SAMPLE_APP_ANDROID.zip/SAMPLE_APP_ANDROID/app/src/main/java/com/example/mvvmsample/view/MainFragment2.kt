package com.example.mvvmsample.view

import android.Manifest.permission.ACCESS_FINE_LOCATION
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import com.example.mvvmsample.R
import com.example.mvvmsample.databinding.Fragment2LayoutBinding
import com.example.mvvmsample.model.MyItem
import com.example.mvvmsample.viewmodel.MainViewModel
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapsInitializer
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.maps.android.clustering.ClusterManager


//
// Created by muruganantham.selvam on 23/11/23.
// Copyright (c) 2023 Botree SoftWare PVT LTd. All rights reserved.
//

class MainFragment2: Fragment(R.layout.fragment2_layout), OnMapReadyCallback,LocationListener {

    // View Binding
    private var _binding: Fragment2LayoutBinding? = null
    // Create a viewModel
    private val viewModel: MainViewModel by activityViewModels()
    private var mMap: GoogleMap? = null
    private lateinit var locationManager: LocationManager
    private val locationPermissionCode = 2
    private lateinit var clusterManager: ClusterManager<MyItem>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = Fragment2LayoutBinding.inflate(inflater, container, false)
        val view = _binding!!.root
        init()
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupClickListeners()
        fragmentTextUpdateObserver()

    }

    private fun init() {

        val mapFragment = childFragmentManager.findFragmentById(R.id.googleMaps) as SupportMapFragment
        mapFragment.getMapAsync(this)



    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
        clusterManager.clearItems()
    }

    // Setup the button in our fragment to call getUpdatedText method in viewModel
    private fun setupClickListeners() {
        _binding?.fragmentButton?.setOnClickListener {
            viewModel.setUpdateText("Hi I am Fragment 2")
            viewModel.getUpdatedText()
        }
    }

    // Observer is waiting for viewModel to update our UI
    private fun fragmentTextUpdateObserver() {
        viewModel.uiTextLiveData.observe(viewLifecycleOwner, Observer { updatedText ->
            _binding?.fragmentTextView?.text = updatedText
        })
    }

        override fun onMapReady(p0: GoogleMap) {
        mMap=p0;
        // Add a marker in Sydney and move the camera
        val sydney = LatLng(-34.0, 151.0)
        mMap!!.addMarker(
            MarkerOptions()
            .position(sydney)
            .title("Marker in Sydney"))
        mMap!!.moveCamera(CameraUpdateFactory.newLatLng(sydney))

        getLocation()
    }
    private fun setUpClusterer() {
        // Position the map.
        mMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(13.0827, 80.2707), 8f))

        // Initialize the manager with the context and the map.
        // (Activity extends context, so we can pass 'this' in the constructor.)
        clusterManager = ClusterManager(context, mMap)

        // Point the map's listeners at the listeners implemented by the cluster
        // manager.
        mMap?.setOnCameraIdleListener(clusterManager)
        mMap?.setOnMarkerClickListener(clusterManager)

        // Add cluster items (markers) to the cluster manager.
        addItems()
    }
    var l:Double=0.0;
    private fun addItems() {
        // Set some lat/lng coordinates to start with.
        var lat = 13.0827+l
        var lng = 80.2707+l

        // Add ten cluster items in close proximity, for purposes of this example.
        for (i in 0..9) {
            l=l+0.1
            val offset = i / 60.0
            lat += offset
            lng += offset
            val offsetItem =
                MyItem(lat, lng, "Title $i", "Snippet $i")
            clusterManager.addItem(offsetItem)
           // clusterManager.setAnimation(true)

        }
    }


    private fun getLocation() {
        locationManager =requireActivity(). getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if ((ContextCompat.checkSelfPermission(requireContext(), ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)) {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(ACCESS_FINE_LOCATION), locationPermissionCode)
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 0f, this)
    }

    override fun onLocationChanged(location: Location) {
        val sydney = LatLng(/*location.latitude*/13.0827 , /*location.longitude*/80.2707)
        mMap!!.addMarker(
            MarkerOptions()
                .position(sydney)
                .title("Marker in Sydney"))
        mMap!!.moveCamera(CameraUpdateFactory.newLatLng(sydney))
        setUpClusterer()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationPermissionCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            //    Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show()
            }
            else {
              //  Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

}