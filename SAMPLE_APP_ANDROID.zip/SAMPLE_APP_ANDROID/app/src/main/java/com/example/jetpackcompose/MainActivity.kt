package com.example.jetpackcompose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment.Companion.CenterVertically
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.layoutId
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.jetpackcompose.ui.theme.JetPackCOmposeAppTheme
import com.example.mvvmsample.R

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme{
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.wrapContentHeight().fillMaxWidth(),
                    color = MaterialTheme.colorScheme.primary
                ) {
                    MessageCard(Message("Hi Message card", "chennai", "guindy"))

                }
            }
        }
    }
}

data class Message(var s: String, var s1: String, var s2: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessageCard(name: Message) {
    // Add padding around our message
    Row(modifier = Modifier.padding(5.dp).border(4.dp, Color.Cyan).height(480.dp)) {
        Image(
            painter = painterResource(R.drawable.ic_launcher_background),
            contentDescription = "Contact profile picture",
            modifier = Modifier
                .align(CenterVertically)
                // Set image size to 40 dp
               // .size(70.dp, 90.dp)
                // Clip image to be shaped as a circle
                .clip(CircleShape)
                .layoutId("imageid"))

        // Add a horizontal space between the image and the column
        Spacer(modifier = Modifier.width(3.dp))

        Column(modifier = Modifier.padding(5.dp)) {

            val gradientColors = listOf(Color.Blue, Color.Cyan, Color.Red, Color.Green, Color.Magenta)
            var text by remember { mutableStateOf("") }

            Text(
                text = "Hello ${name.s}!",
                style = textStyleNew(FontStyle.Normal,
                     FontWeight.ExtraBold,Color.Cyan,Color.Red)
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = "Hello ${name.s1}",
                style = textStyleNew(FontStyle.Normal,
                    FontWeight.ExtraBold,Color.Cyan,Color.White)
            )
            //vertical Sapce
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = "Hello ${name.s2}",
                color = Color.Green, fontSize = 20.sp,
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.W100
            )
            //vertical Sapce
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = name.s,
                style = TextStyle(
                    brush = Brush.linearGradient(
                        colors = gradientColors
                    )
                )
            )
            Spacer(modifier = Modifier.height(3.dp))

            Text(
                buildAnnotatedString {
                    withStyle(style = SpanStyle(color = Color.Blue)) {
                        append("H")
                    }
                    withStyle(style = SpanStyle(color = Color.Cyan)) {
                        append("ello ")

                    }

                    withStyle(style = SpanStyle(fontWeight = FontWeight.Bold, color = Color.Red)) {
                        append("W")
                    }
                    withStyle(style = SpanStyle(fontWeight = FontWeight.Bold, color = Color.Cyan)) {
                        append("orld")
                    }

                }
            )
            Spacer(modifier = Modifier.height(3.dp))

            Text(
                text = buildAnnotatedString {
                    append("Do not allow people to dim your shine\n")
                    withStyle(
                        SpanStyle(
                            brush = Brush.linearGradient(
                                colors = gradientColors
                            )
                        )
                    ) {
                        append("because they are blinded.")
                    }
                    append("\nTell them to put some sunglasses on.")
                }
            )
            Text("Hello Compose ".repeat(50), maxLines = 2, overflow = TextOverflow.Ellipsis,
                style = textStyleNew(FontStyle.Normal,
                    FontWeight.ExtraBold,Color.Cyan,Color.Red))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("Label") }
            )
        }
    }

}

@Preview(showBackground = true)
@Composable
fun PreviewMessageCard() {
    JetPackCOmposeAppTheme(true) {
        MaterialTheme {
            MessageCard(Message("Hi Message card", "Botree", "SOftware"))

        }
    }
}
@Composable
fun textStyleNew(font: FontStyle, fontweight: FontWeight, color: Color,FontColor:Color): TextStyle{
    var offset = Offset(5.0f, 10.0f)
    var style = TextStyle(
        color = FontColor,
        fontSize = 20.sp,
        fontStyle = font,
        fontWeight =fontweight,
        shadow = Shadow(
            color = color, offset = offset, blurRadius = 2f
        )
    )
    return style;
}

