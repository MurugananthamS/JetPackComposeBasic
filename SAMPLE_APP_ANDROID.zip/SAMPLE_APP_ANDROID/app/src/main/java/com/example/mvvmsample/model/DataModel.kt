package com.example.mvvmsample.model


//
// Created by muruganantham.selvam on 21/11/23.
// Copyright (c) 2023 Botree SoftWare PVT LTd. All rights reserved.
//

data class DataModel(var textForUI: String)
