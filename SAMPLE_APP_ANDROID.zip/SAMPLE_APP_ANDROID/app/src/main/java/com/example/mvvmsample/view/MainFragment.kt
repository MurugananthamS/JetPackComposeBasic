package com.example.mvvmsample.view

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.navigation.findNavController
import com.example.mvvmsample.viewmodel.MainViewModel
import com.example.mvvmsample.databinding.MainFagmentlayoutBinding


//
// Created by muruganantham.selvam on 21/11/23.
// Copyright (c) 2023 Botree SoftWare PVT LTd. All rights reserved.
//

class MainFragment: Fragment() {

    // View Binding
    private var _binding: MainFagmentlayoutBinding? = null
    private val binding get() = _binding!!

    // Create a viewModel
    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = MainFagmentlayoutBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupClickListeners()
        fragmentTextUpdateObserver()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // Setup the button in our fragment to call getUpdatedText method in viewModel
    private fun setupClickListeners() {
        binding.fragmentButton.setOnClickListener { viewModel.getUpdatedText() }

        binding.fragmentTextView2.setOnClickListener {
          /*  val intent = Intent(requireActivity(), ComposableSampleActivity::class.java)
            intent.putExtra("key", "value")
            startActivity(intent)  */
           val action =
                MainFragmentDirections
                    .actionMainFragmentToMainFragment3()
            view?.findNavController()?.navigate(action)
        }

        binding.fragmentTextView.setOnClickListener {
            val action =
                MainFragmentDirections
                    .actionMainFragmentToMainFragment2()
            view?.findNavController()?.navigate(action)
        }
    }

    // Observer is waiting for viewModel to update our UI
    private fun fragmentTextUpdateObserver() {
        viewModel.uiTextLiveData.observe(viewLifecycleOwner, Observer { updatedText ->
            binding.fragmentTextView.text = updatedText
        })
    }
}