package com.example.mvvmsample.view

import android.os.Bundle
import android.os.Message
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mvvmsample.R
import com.example.mvvmsample.databinding.MainActivitylayoutBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: MainActivitylayoutBinding
    lateinit var fragment: MainFragment
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // Text("Hello world!")
            MessageCard(Message("Hi Message card", "chennai", "guindy"))

        }

        /*
           binding=MainActivitylayoutBinding.inflate(layoutInflater)
           var view= binding.root
           setContentView(view)val navHostFragment =
               supportFragmentManager.findFragmentById(R.id.fragment_container_view) as NavHostFragment
           val navController = navHostFragment.navController
   */
    }

    data class Message(var s: String, var s1: String, var s2: String)

    @Composable
    fun MessageCard(name: Message) {
        // Add padding around our message
        Row(modifier = Modifier.padding(5.dp)) {
            Image(
                painter = painterResource(R.drawable.ic_launcher_background),
                contentDescription = "Contact profile picture",
                modifier = Modifier
                    // Set image size to 40 dp
                    .size(70.dp,90.dp)
                    // Clip image to be shaped as a circle
                    .clip(CircleShape)
            )
            // Add a horizontal space between the image and the column
            Spacer(modifier = Modifier.width(3.dp))

            Column(modifier = Modifier.padding(5.dp)) {
                Text(
                    text = "Hello ${name.s}!",
                    color = Color.Red, fontSize = 20.sp
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "Hello ${name.s1}",
                    color = Color.White, fontSize = 20.sp
                )
                //vertical Sapce
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "Hello ${name.s2}",
                    color = Color.Green, fontSize = 20.sp
                )

            }
        }

    }

    @Preview
    @Composable
    fun PreviewMessageCard() {
        MessageCard(Message("Hi Message card", "chennai", "guindy"))
    }
}
